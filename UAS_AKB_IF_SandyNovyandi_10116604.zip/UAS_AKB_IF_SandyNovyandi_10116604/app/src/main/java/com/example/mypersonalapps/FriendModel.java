package com.example.mypersonalapps;
/*Nama : Sandy Novyandi
NIM  : 10116604
KELAS : AKB-IF4
Tanggal Pengerjaan : 09 Agustus 2019*/
public class FriendModel {

    private int nim;
    private String nama;
    private String kelas;
    private String nohp;
    private String email;
    private String sosmed;

    public int getNim(){
        return nim;
    }
    public void setNim(int nim){
        this.nim=nim;
    }
    public String getNama(){
        return nama;
    }
    public void setNama(String nama){
        this.nama=nama;
    }
    public String getKelas(){
        return kelas;
    }
    public void setKelas(String kelas){
        this.kelas=kelas;
    }
    public String getNohp(){
        return nohp;
    }
    public void setNohp(String nohp){
        this.nohp=nohp;
    }
    public String getEmail(){
        return email;
    }
    public void setEmail(String email){
        this.email=email;
    }
    public String getSosmed(){
        return sosmed;
    }
    public void setSosmed(String sosmed){
        this.sosmed=sosmed;
    }
}
